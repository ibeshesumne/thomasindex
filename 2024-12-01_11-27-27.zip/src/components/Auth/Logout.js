import React, { useState } from 'react';
import { signOut } from 'firebase/auth';
import { auth } from '../../firebase';
import { useNavigate } from 'react-router-dom';

const Logout = () => {
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    setIsLoading(true); // Start loading state
    try {
      await signOut(auth);
      setIsLoading(false); // Stop loading state
      navigate('/login'); // Redirect to the login page
    } catch (err) {
      console.error('Error during logout:', err);
      setIsLoading(false); // Stop loading state on error
    }
  };

  return (
    <div>
      <button
        onClick={handleLogout}
        disabled={isLoading}
        className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
      >
        {isLoading ? 'Logging Out...' : 'Logout'}
      </button>
    </div>
  );
};

export default Logout;
