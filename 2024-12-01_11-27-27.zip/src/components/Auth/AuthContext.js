import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, getAuth } from 'firebase/auth';
import { ref, get } from 'firebase/database';
import { db } from '../../firebase'; // Adjust the path to your firebase.js

// Create the AuthContext
const AuthContext = createContext();

// AuthProvider component to wrap the app
export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [userType, setUserType] = useState('regular'); // Default userType
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const auth = getAuth();

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);

        try {
          // Fetch userType from Realtime Database
          const userRef = ref(db, `users/${user.uid}/userType`);
          const snapshot = await get(userRef);

          if (snapshot.exists()) {
            setUserType(snapshot.val());
          } else {
            console.warn('No userType found; defaulting to regular.');
            setUserType('regular'); // Default to 'regular' if no userType exists
          }
        } catch (error) {
          console.error('Error fetching userType:', error.message);
          setUserType('regular'); // Fallback to 'regular' on error
        }
      } else {
        setCurrentUser(null);
        setUserType('regular'); // Reset to 'regular' on logout
      }

      setLoading(false);
    });

    return () => unsubscribe(); // Cleanup subscription on unmount
  }, []);

  const value = {
    currentUser,
    userType,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

// Custom hook to use AuthContext
export const useAuth = () => {
  return useContext(AuthContext);
};
