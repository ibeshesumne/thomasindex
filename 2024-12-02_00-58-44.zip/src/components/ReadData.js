import React, { useEffect, useState } from 'react';
import { db } from '../firebase';
import { ref, onValue } from 'firebase/database';
import { CSVLink } from 'react-csv';
import { useAuth } from './Auth/AuthContext';

function ReadData({ selectedRecord, setSelectedRecord }) {
  const [records, setRecords] = useState([]);
  const { currentUser, userType } = useAuth();

  useEffect(() => {
    if (!currentUser) {
      alert('You must be logged in to view records.');
      setRecords([]);
      return;
    }

    const recordsRef = ref(db, 'letters');

    const unsubscribe = onValue(recordsRef, (snapshot) => {
      if (!snapshot.exists()) {
        console.log('No records found.');
        setRecords([]);
        return;
      }

      const allRecords = Object.entries(snapshot.val()).map(([id, data]) => ({
        id,
        ...data,
      }));

      if (userType === 'admin') {
        setRecords(allRecords);
      } else {
        const userRecords = allRecords.filter((record) => record.createdBy === currentUser.uid);
        setRecords(userRecords);
      }
    });

    return () => unsubscribe();
  }, [currentUser, userType]);

  const headers = [
    { label: 'ID', key: 'id' },
    { label: 'Created By', key: 'createdByEmail' },
    { label: 'Date Checker', key: 'datechecker' },
    { label: 'Date', key: 'date' },
    { label: 'Object Type', key: 'object_type' },
    { label: 'Sender', key: 'sender' },
    { label: 'Receiver', key: 'receiver' },
    { label: 'Location of Object', key: 'location_object' },
    { label: 'Location of Original', key: 'location_original' },
    { label: 'Object URL', key: 'object_url' },
    { label: 'Original URL', key: 'original_url' },
    { label: 'Notes', key: 'notes' },
    { label: 'Index Creation Date', key: 'index_creation_date' },
    { label: 'Index Modified Date', key: 'index_modified_date' },
  ];

  const handleRecordClick = (record) => {
    setSelectedRecord(record);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-3xl bg-white shadow-md rounded-lg p-8">
        <h3 className="text-2xl font-bold mb-4">
          {userType === 'admin' ? 'All Records' : 'Your Records'}
        </h3>
        {records.length === 0 ? (
          <p className="text-gray-500">No records available</p>
        ) : (
          <>
            <CSVLink
              data={records}
              headers={headers}
              filename="letters_records.csv"
              className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mb-4 inline-block"
            >
              Export All Records to CSV
            </CSVLink>
            <ul className="list-none p-0 space-y-4">
              {records.map((record) => (
                <li
                  key={record.id}
                  className="p-4 border border-gray-300 rounded flex justify-between items-center"
                >
                  <div>
                    <strong>ID:</strong> {record.id} |{' '}
                    {userType === 'admin' && (
                      <span>
                        <strong>Created By:</strong> {record.createdByEmail} |{' '}
                      </span>
                    )}
                    <strong>Type:</strong> {record.object_type} |{' '}
                    <strong>Sender:</strong> {record.sender} |{' '}
                    <strong>Receiver:</strong> {record.receiver}
                  </div>
                  <button
                    onClick={() => handleRecordClick(record)}
                    className="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded"
                  >
                    Review Record
                  </button>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </div>
  );
}

export default ReadData;
